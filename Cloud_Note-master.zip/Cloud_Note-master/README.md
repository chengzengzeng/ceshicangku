# Cloud_Note
Spring+Spring MVC+Mybatis开发的云笔记项目
具体文档图可参考https://blog.csdn.net/Mind_programmonkey/article/details/80229686
在源码中包含以下：整个项目的源码，项目所需的HTML网页，项目所需的建表语句，以及项目的文档说明
