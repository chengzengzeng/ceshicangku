// 服务端访问路径
var base_path="http://localhost:8080/cloud_note";
